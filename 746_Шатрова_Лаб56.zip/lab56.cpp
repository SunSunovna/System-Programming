#include <stdio.h>
#include <cstring>
#include <iostream>
#include <dirent.h>
#include <pthread.h>

using namespace std;

string buff_out_path = "";
string buff_in_path = "";

pthread_cond_t thread_cv;
pthread_mutex_t thread_mutex;
pthread_mutex_t thread_mutex_out;
pthread_barrier_t thread_end;

void *thread(void *arg)
{
    string rezult = "";

    pthread_mutex_lock(&thread_mutex);

    string local_buff="cp " + buff_out_path + " " + buff_in_path;

    pthread_cond_signal(&thread_cv);
    pthread_mutex_unlock(&thread_mutex);
    
    //cout<<"thread GO!"<<endl;
             
        if (system(local_buff.c_str()))
            rezult = "Failed";
        else
            rezult = "Successful";

    pthread_mutex_lock(&thread_mutex_out);
    cout << local_buff << endl;
    cout << rezult << endl;
    //cout << "thread end\n";
    pthread_mutex_unlock(&thread_mutex_out);
    pthread_barrier_wait(&thread_end);

return 0;
}

int main(int argc, char **file_1) 
{
    pthread_t tid; //переменная, где хранится id потока
    buff_in_path = file_1[2];
    //file_1[1] - из какой директории копируем, "/home/746-saa1/dir_lab4/"
    //file_1[2] - в какую директорию копируем, "/home/746-saa1/"

    cout <<"thread create \n";
    DIR *dir = opendir(file_1[1]);
    struct dirent *entry;
    if (!dir)
    {
        perror("diropen");
        exit(1);
    }
    int i=0;
    while ((entry = readdir(dir))!=NULL)
        if (entry->d_name[0]!= '.')
            i++;

    pthread_barrier_init(&thread_end, nullptr,i+1);

    closedir(dir);
    dir = opendir(file_1[1]);
    
    pthread_mutex_lock(&thread_mutex);  //блокировка мьютекса (lock - попытка занять мьютекс, если занят - ждем)
    while ((entry = readdir(dir))!=NULL)
    {
        buff_out_path = entry->d_name; // d_name - название файла
        if (buff_out_path[0] != '.')
        {
            buff_out_path = file_1[1] + buff_out_path; // полный путь к файлу
            
            pthread_mutex_lock(&thread_mutex_out);
            cout << buff_out_path << endl;
            pthread_mutex_unlock(&thread_mutex_out);

            pthread_create(&tid,nullptr,thread,nullptr); // создание потока
            pthread_detach(tid);

            pthread_cond_wait(&thread_cv,&thread_mutex);
        }
    }   
    closedir(dir);
    pthread_mutex_unlock(&thread_mutex);

    pthread_barrier_wait(&thread_end);

    pthread_mutex_destroy(&thread_mutex);
    pthread_cond_destroy(&thread_cv);

    //system("find /home/746-saa1/dir_lab4/ -maxdepth 1 -type f");

    return 0;
}